#!/usr/bin/env bash
# Send synthetic Wazuh / ModSecurity / Suricata-shaped events to threat-central POST /logs.
# Use on the VM (localhost) or from your laptop against the VM external IP / SSH tunnel.
#
# Examples:
#   ./scripts/simulate-alerts.sh
#   ./scripts/simulate-alerts.sh --count 50 --interval 0.5
#   BASE_URL=http://VM_IP:8080 ./scripts/simulate-alerts.sh --burst
#   ./scripts/simulate-alerts.sh --sources suricata,wazuh

set -euo pipefail

BASE_URL="${BASE_URL:-http://127.0.0.1:8080}"
COUNT=20
INTERVAL=1
SOURCES="suricata,modsec,wazuh"
BURST=0
DRY_RUN=0

usage() {
  sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'
  echo ""
  echo "Options:"
  echo "  --url URL          Receiver base URL (default: \$BASE_URL or http://127.0.0.1:8080)"
  echo "  --count N          Alerts per source type (default: 20)"
  echo "  --interval SEC     Pause between rounds (default: 1; ignored with --burst)"
  echo "  --sources LIST     Comma-separated: suricata,modsec,wazuh (default: all)"
  echo "  --burst            Send all alerts as fast as possible"
  echo "  --dry-run          Print payloads, do not POST"
  echo "  -h, --help         This help"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --url) BASE_URL="$2"; shift 2 ;;
    --count) COUNT="$2"; shift 2 ;;
    --interval) INTERVAL="$2"; shift 2 ;;
    --sources) SOURCES="$2"; shift 2 ;;
    --burst) BURST=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

IFS=',' read -r -a SOURCE_LIST <<< "$SOURCES"

rand_ip() {
  # RFC 5737 documentation ranges — safe for lab traffic.
  local n=$((RANDOM % 250 + 1))
  case $((RANDOM % 3)) in
    0) printf '203.0.113.%s' "$n" ;;
    1) printf '198.51.100.%s' "$n" ;;
    *) printf '192.0.2.%s' "$n" ;;
  esac
}

suricata_payload() {
  local ip="$1" seq="$2"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%S.000000+0000")"
  local sev=$((RANDOM % 3 + 1))
  cat <<EOF
[{
  "timestamp": "$ts",
  "event_type": "alert",
  "src_ip": "$ip",
  "dest_port": 443,
  "alert": {
    "signature": "ET SIM suricata probe #$seq",
    "severity": $sev,
    "category": "simulation"
  },
  "http": { "url": "/sim/suricata/$seq" }
}]
EOF
}

modsec_payload() {
  local ip="$1" seq="$2"
  local ts
  ts="$(date -u +"%a %b %d %H:%M:%S %Y")"
  local sev=$((RANDOM % 3 + 3))
  cat <<EOF
[{
  "transaction": {
    "client_ip": "$ip",
    "time_stamp": "$ts",
    "host_port": 443,
    "request": { "uri": "/sim/modsec/$seq" },
    "messages": [{
      "message": "simulated modsec event",
      "details": {
        "match": "Simulated ModSecurity rule #$seq",
        "severity": "$sev"
      }
    }]
  }
}]
EOF
}

wazuh_payload() {
  local ip="$1" seq="$2"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  local level=$((RANDOM % 12 + 4))
  cat <<EOF
[{
  "timestamp": "$ts",
  "agent": { "id": "sim-$seq", "name": "sim-agent", "ip": "$ip" },
  "rule": {
    "id": $((10000 + seq)),
    "level": $level,
    "description": "Simulated Wazuh alert #$seq"
  }
}]
EOF
}

post_log() {
  local log_type="$1" body="$2"
  if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "--- $log_type ---"
    echo "$body"
    return 0
  fi
  local code
  code=$(curl -sS -o /dev/null -w "%{http_code}" -X POST "$BASE_URL/logs" \
    -H "Log-Type: $log_type" \
    -H "Content-Type: application/json" \
    -d "$body") || {
    echo "curl failed for $log_type" >&2
    return 1
  }
  if [[ "$code" != "204" ]]; then
    echo "POST /logs ($log_type) returned HTTP $code (expected 204)" >&2
    return 1
  fi
  echo "sent $log_type -> 204"
}

send_round() {
  local i="$1"
  local ip
  ip="$(rand_ip)"
  local src
  for src in "${SOURCE_LIST[@]}"; do
    case "$src" in
      suricata) post_log suricata "$(suricata_payload "$ip" "$i")" ;;
      modsec)   post_log modsec   "$(modsec_payload "$ip" "$i")" ;;
      wazuh)    post_log wazuh    "$(wazuh_payload "$ip" "$i")" ;;
      *) echo "unknown source: $src" >&2; exit 1 ;;
    esac
  done
}

echo "Target: $BASE_URL/logs"
echo "Plan: $COUNT round(s) x sources (${SOURCES})"

if [[ "$DRY_RUN" -eq 0 ]]; then
  code=$(curl -sS -o /dev/null -w "%{http_code}" "$BASE_URL/health" || echo "000")
  if [[ "$code" != "200" ]]; then
    echo "Health check failed (HTTP $code). Is threat-central listening?" >&2
    exit 1
  fi
fi

for ((i = 1; i <= COUNT; i++)); do
  echo "== round $i/$COUNT =="
  send_round "$i"
  if [[ "$BURST" -eq 0 && "$i" -lt "$COUNT" ]]; then
    sleep "$INTERVAL"
  fi
done

echo ""
echo "Done. Verify:"
echo "  curl -sS http://127.0.0.1:2112/metrics | grep threat_central_"
echo "  Grafana :3000  |  Prometheus :9090  |  Firestore alerts collection"
