# Send synthetic alerts to threat-central POST /logs (Windows / PowerShell).
#
#   .\scripts\simulate-alerts.ps1
#   .\scripts\simulate-alerts.ps1 -BaseUrl "http://VM_IP:8080" -Count 50 -IntervalSeconds 0.5
#   .\scripts\simulate-alerts.ps1 -Burst

param(
    [string] $BaseUrl = $(if ($env:BASE_URL) { $env:BASE_URL } else { "http://127.0.0.1:8080" }),
    [int] $Count = 20,
    [double] $IntervalSeconds = 1,
    [string] $Sources = "suricata,modsec,wazuh",
    [switch] $Burst,
    [switch] $DryRun
)

$ErrorActionPreference = "Stop"
$sourceList = $Sources -split "," | ForEach-Object { $_.Trim() }

function Get-RandIp {
    $n = Get-Random -Minimum 1 -Maximum 254
    switch (Get-Random -Maximum 3) {
        0 { "203.0.113.$n" }
        1 { "198.51.100.$n" }
        default { "192.0.2.$n" }
    }
}

function New-SuricataPayload([string]$Ip, [int]$Seq) {
    $ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.000000+0000")
    $sev = Get-Random -Minimum 1 -Maximum 4
    @(
        @{
            timestamp = $ts
            event_type = "alert"
            src_ip = $Ip
            dest_port = 443
            alert = @{
                signature = "ET SIM suricata probe #$Seq"
                severity = $sev
                category = "simulation"
            }
            http = @{ url = "/sim/suricata/$Seq" }
        }
    ) | ConvertTo-Json -Depth 6 -Compress
}

function New-ModsecPayload([string]$Ip, [int]$Seq) {
    $ts = (Get-Date).ToUniversalTime().ToString("ddd MMM dd HH:mm:ss yyyy")
    $sev = Get-Random -Minimum 3 -Maximum 6
    @(
        @{
            transaction = @{
                client_ip = $Ip
                time_stamp = $ts
                host_port = 443
                request = @{ uri = "/sim/modsec/$Seq" }
                messages = @(
                    @{
                        message = "simulated modsec event"
                        details = @{
                            match = "Simulated ModSecurity rule #$Seq"
                            severity = "$sev"
                        }
                    }
                )
            }
        }
    ) | ConvertTo-Json -Depth 8 -Compress
}

function New-WazuhPayload([string]$Ip, [int]$Seq) {
    $ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    $level = Get-Random -Minimum 4 -Maximum 16
    @(
        @{
            timestamp = $ts
            agent = @{ id = "sim-$Seq"; name = "sim-agent"; ip = $Ip }
            rule = @{
                id = 10000 + $Seq
                level = $level
                description = "Simulated Wazuh alert #$Seq"
            }
        }
    ) | ConvertTo-Json -Depth 6 -Compress
}

function Send-Log([string]$LogType, [string]$Body) {
    if ($DryRun) {
        Write-Host "--- $LogType ---"
        Write-Host $Body
        return
    }
    $headers = @{
        "Log-Type" = $LogType
        "Content-Type" = "application/json"
    }
    try {
        Invoke-WebRequest -Uri "$BaseUrl/logs" -Method POST -Headers $headers -Body $Body -UseBasicParsing | Out-Null
        Write-Host "sent $LogType -> 204"
    } catch {
        $status = $_.Exception.Response.StatusCode.value__
        Write-Error "POST /logs ($LogType) failed (HTTP $status): $_"
    }
}

Write-Host "Target: $BaseUrl/logs"
Write-Host "Plan: $Count round(s) x sources ($Sources)"

if (-not $DryRun) {
    $health = Invoke-WebRequest -Uri "$BaseUrl/health" -UseBasicParsing
    if ($health.StatusCode -ne 200) {
        throw "Health check failed (HTTP $($health.StatusCode))"
    }
}

for ($i = 1; $i -le $Count; $i++) {
    Write-Host "== round $i/$Count =="
    $ip = Get-RandIp
    foreach ($src in $sourceList) {
        switch ($src) {
            "suricata" { Send-Log "suricata" (New-SuricataPayload $ip $i) }
            "modsec"   { Send-Log "modsec"   (New-ModsecPayload $ip $i) }
            "wazuh"    { Send-Log "wazuh"    (New-WazuhPayload $ip $i) }
            default    { throw "unknown source: $src" }
        }
    }
    if (-not $Burst -and $i -lt $Count) {
        Start-Sleep -Seconds $IntervalSeconds
    }
}

$metricsUrl = $BaseUrl -replace ':8080$', ':2112'
Write-Host ""
Write-Host "Done. Check metrics: ${metricsUrl}/metrics"
